# Implementar-un-Reproductor-de-Musica-Radio-Online-en-Android-Studio-en-el-Lenguaje-de-Programa
Implementación de un Reproductor de Musica, Radio Online en Android Studio en el Lenguaje de Programacion Kotlin

¿Que es MediaPlayer?

Es un marco de trabajo de contenido multimedia de Android admite la reproducción de diferentes tipos de contenido multimedia habituales para que puedas integrar audio, clip de video e imágenes con facilidad en tus aplicaciones. Puedes reproducir audio o clip de video a partir de archivos multimedia almacenados en los recursos de tu app (recursos sin procesar), a partir de archivos independientes del sistema de archivos o a partir de un flujo de datos que llega por medio de una conexión de red, todo por medio de diferentes API de MediaPlayer.

Como conceptos básicos poseemos:

La clases mediaplayer es la API base para reproducir sonido y vídeo.
La clase AudioManager que administra fuentes y salidas de audio en el dispositivo.

![image](https://user-images.githubusercontent.com/81777537/147771239-762669c1-8108-427a-bd4b-cd77a852a0b3.png)

Pasos Para el Desarrollo en Android Studio y Kotlin
En este tutorial aprenderas a realizar un reproductor de streaming de música implementando radio Online en android studio con el lenguaje de programacion kotlin usando una clase llamada MediaPlayer para el desarrollo de aplicaciones Android, comprender la estructura de un proyecto Android, identificar los principales componentes que pueden formar parte de una aplicación, y por supuesto, desarrollaras tu primera aplicación  de radio usando mediapalyer de principio a fin, desde la creación del proyecto hasta su ejecución en el emulador de Android.

Blog-Kotlin  https://systempg.blogspot.com/
